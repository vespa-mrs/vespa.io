Siemens DICOM Spectral Data - summed FIDs
---------------------------------------------

data\_TrioRaw_2009\09072800_soher_TEstep_teAvg

which is a phantom study on the 3T Trio system.  The phantom was a braino ball, data was taken with a PRESS short TE sequence with the following parameters

Spectral Dim0 ...................... 1024
Spatial  Dim1 ...................... 1
Spatial  Dim2 ...................... 1
Spatial  Dim3 ...................... 1
Spectral Sweep Width (Hz) .......... 2000.0000
Spectral Hz per Pt ................. 1.9531250
Spectrometer Frequency (MHz) ....... 123.25101
Data Type .......................... complexfloat
Data Format ........................ xdr

This file is a DICOM file exported from the Siemens scanner.

There were 3 series in this study, only series 2 is in this folder since series 1 contained standard MR image data, and series 3 is a different example in the sample_data directory.

Series 2 has one file that contains the sum of the 128 data acquisitions (averages) of 1024 points that was acquired by the standard Siemens processing into one DICOM file. 



