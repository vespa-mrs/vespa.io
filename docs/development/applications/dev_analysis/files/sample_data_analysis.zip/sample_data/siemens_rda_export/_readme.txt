
Siemens DICOM Spectral Data - all FIDs sumemd
-----------------------------------------------


which is a phantom study on the 3T Trio system.  The phantom was a braino ball, data was taken with a PRESS short TE (30 ms) sequence with the following parameters

Spectral Dim0 ...................... 1024
Spatial  Dim1 ...................... 1
Spatial  Dim2 ...................... 1
Spatial  Dim3 ...................... 1
Spectral Sweep Width (Hz) .......... 2000.0000
Spectral Hz per Pt ................. 1.171875
Spectrometer Frequency (MHz) ....... 123.25101
Data Type .......................... complexfloat
Data Format ........................ xdr

The file is a *.RDA file exported from the Siemens scanner.