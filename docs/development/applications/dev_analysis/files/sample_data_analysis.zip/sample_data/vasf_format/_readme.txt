
VASF (VA San Francisco) File Format Data
---------------------------------------------

The VASF format has two files, a header file and data file, with extensions *.rsp/*.rsd which stand for 'raw spectroscopic parameters/data' respectively. The *.rsp file is a text file containing parameter values in a format similar to a Windows "ini" file.  The *.rsd data file is a binary file containing only data.

This data set has data for 7 different TE times and the corresponding water spectrum for each TE time.  Thus there are 7 (TE) x 2 (water-metab) x 2 (data-header) = 28 files.  The TEs range from approximately 24ms to 144ms in steps of 20ms.  Thus press_cp0 files area TE=24, press_cp1 files are TE=44, etc.

Spectral Dim0 ...................... 4096
Spatial  Dim1 ...................... 1
Spatial  Dim2 ...................... 1
Spatial  Dim3 ...................... 1
Spectral Sweep Width (Hz) .......... 3906.25
Spectral Hz per Pt ................. 0.9536743
Spectrometer Frequency (MHz) ....... 63.71824
Data Type .......................... complexfloat
Data Format ........................ xdr

This is a good example data set to try out the ECC filters on, because we have the corresponding water spectrum for each metabolite file.