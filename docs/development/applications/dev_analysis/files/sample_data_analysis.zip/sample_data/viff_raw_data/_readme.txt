
VIFF (Vespa Interchange File Format) Raw Data
---------------------------------------------


Spectral Dim0 ...................... 2048
Spatial  Dim1 ...................... 1
Spatial  Dim2 ...................... 1
Spatial  Dim3 ...................... 1
Spectral Sweep Width (Hz) .......... 1024.0
Spectral Hz per Pt ................. 0.5
Spectrometer Frequency (MHz) ....... 64.0
Data Type .......................... complexfloat
Data Format ........................ xdr

This file contains a simulated PRESS TE=20 data set. Metabolites included are: choline-truncated, creatine, gaba, glutamate, glutamine, myo-inositol, n-acetylaspartate, taurine. Additional information on content is in the file header and comment.

This file was created using the standalone application Prior that takes Vespa-Simulation Experiment results and allows the user to create simulated data with metabolite signals, baseline signals and added noise.

